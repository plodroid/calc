# Greywake

Greywake is a small atmospheric horror mod for Fabric on Minecraft Java 1.21.11.

## Requirements

- Minecraft Java 1.21.11
- Java 21+
- Fabric Loader 0.19.3+
- Fabric API 0.141.6+1.21.11 (or a compatible newer 1.21.11 build)

## The Still

Craft a **Still Core** and a **Wake Needle**. Build the ritual at one Y level:

```text
Soul Sand | Sculk | Soul Sand
Sculk     | Still Core | Sculk
Soul Sand | Sculk | Soul Sand
```

Keep the block directly above the Still Core empty. Use a Wake Needle on the core. After a short telegraphed warm-up, a one-way rift opens above the core.

The Needle is consumed when the ritual begins. To leave the Wake, build another complete Still inside the Wake and spend another Wake Needle. Going in is intentionally easier than getting home.

## Core systems

- **The Wake**: independently generated fixed-biome dimension with dense grey fog, dim lighting, no normal mob population, and terrain that slowly turns ash-grey around explorers.
- **Echoes**: a server-authoritative delayed Husk-like humanoid that follows samples of your own movement from roughly 30-60 seconds ago. Contact attacks are audibly/visually telegraphed before damage.
- **Bleed**: every third successful Wake entry creates or strengthens a permanent grey patch around the Overworld Still used. Patches persist in `greywake-state.json`, alter terrain, make night ambience stranger and can rarely produce hostile Echoes.
- **The Guest**: after seven total levels of Bleed, a one-time named Wither Skeleton encounter can manifest at night inside a Bleed patch. It is warned well in advance, never respawns after defeat, and leaves the permanent scars behind.

## Configuration

The mod creates `config/greywake.json` with timing/damage/Bleed thresholds that can be tuned for an SMP.

## Art hooks

The functional placeholder art is intentionally simple. Replace these without touching Java code:

- `assets/greywake/textures/block/still_core.png`
- `assets/greywake/textures/block/rift.png`
- `assets/greywake/textures/item/wake_needle.png`
- `assets/greywake/icon.png`

Echoes and The Guest intentionally use vanilla-backed humanoid renderers in v1.0.0 for maximum dedicated-server reliability; their gameplay identity is controlled server-side.

package dev.plodroid.greywake;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;

public final class GreywakeConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    public static GreywakeConfig INSTANCE = new GreywakeConfig();

    public int ritualWarmupTicks = 60;
    public int riftLifetimeTicks = 600;
    public int echoSampleIntervalTicks = 4;
    public int echoDelayMinTicks = 600;
    public int echoDelayMaxTicks = 1200;
    public int echoStrikeTelegraphTicks = 20;
    public float echoStrikeDamage = 6.0f;
    public int tripsPerBleed = 3;
    public int bleedBaseRadius = 12;
    public int guestBleedThreshold = 7;
    public int wakeCoordinateOffset = 100000;

    private static Path path() {
        return FabricLoader.getInstance().getConfigDir().resolve("greywake.json");
    }

    public static void load() {
        Path path = path();
        try {
            Files.createDirectories(path.getParent());
            if (Files.exists(path)) {
                GreywakeConfig parsed = GSON.fromJson(Files.readString(path, StandardCharsets.UTF_8), GreywakeConfig.class);
                if (parsed != null) INSTANCE = parsed;
            }
            Files.writeString(path, GSON.toJson(INSTANCE), StandardCharsets.UTF_8);
        } catch (IOException e) {
            Greywake.LOGGER.error("Could not read/write Greywake config", e);
        }
    }
}

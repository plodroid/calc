package dev.plodroid.greywake;

import net.minecraft.item.Item;
import net.minecraft.item.ItemUsageContext;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.ActionResult;

public final class WakeNeedleItem extends Item {
    public WakeNeedleItem(Settings settings) {
        super(settings);
    }

    @Override
    public ActionResult useOnBlock(ItemUsageContext context) {
        if (!context.getWorld().getBlockState(context.getBlockPos()).isOf(GreywakeContent.STILL_CORE)) {
            return ActionResult.PASS;
        }

        if (context.getWorld().isClient()) {
            return ActionResult.SUCCESS;
        }

        if (!(context.getWorld() instanceof ServerWorld world) || !(context.getPlayer() instanceof ServerPlayerEntity player)) {
            return ActionResult.PASS;
        }

        return GreywakeServer.activateStill(world, context.getBlockPos(), player, context.getStack())
                ? ActionResult.SUCCESS_SERVER
                : ActionResult.FAIL;
    }
}

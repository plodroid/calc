package dev.plodroid.greywake;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.SpawnReason;
import net.minecraft.entity.attribute.EntityAttributeInstance;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.mob.HuskEntity;
import net.minecraft.entity.mob.WitherSkeletonEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.network.packet.s2c.play.PositionFlag;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.world.Heightmap;
import net.minecraft.world.World;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * All authoritative Greywake gameplay lives here on the logical server.
 * Clients only receive normal vanilla entity, particle, sound, block and teleport packets.
 */
public final class GreywakeServer {
    public static final RegistryKey<World> WAKE = RegistryKey.of(RegistryKeys.WORLD, Greywake.id("wake"));

    private static GreywakeState state = new GreywakeState();
    private static long serverTicks;

    private static final List<PendingRitual> pendingRituals = new ArrayList<>();
    private static final List<ActiveRift> activeRifts = new ArrayList<>();
    private static final Map<UUID, ArrayDeque<MovementFrame>> recordings = new HashMap<>();
    private static final Map<UUID, EchoTrack> echoes = new HashMap<>();
    private static final Map<UUID, Integer> riftCooldown = new HashMap<>();

    private static UUID guestTarget;
    private static int guestCountdown = -1;

    private GreywakeServer() {}

    public static void onServerStarted(MinecraftServer server) {
        state = GreywakeState.load(server);
        serverTicks = 0L;
        pendingRituals.clear();
        activeRifts.clear();
        recordings.clear();
        echoes.clear();
        riftCooldown.clear();
        guestTarget = null;
        guestCountdown = -1;
        Greywake.LOGGER.info("Loaded Greywake state: {} Bleed patch(es), guest manifested={}, defeated={}",
                state.bleedPatches.size(), state.guestManifested, state.guestDefeated);
    }

    public static void onServerStopping(MinecraftServer server) {
        for (EchoTrack track : echoes.values()) {
            for (ServerWorld world : server.getWorlds()) {
                Entity entity = world.getEntity(track.entityUuid);
                if (entity != null && entity.getCommandTags().contains("greywake_echo")) {
                    entity.discard();
                }
            }
        }
        state.save(server);
    }

    public static void onLivingDeath(LivingEntity entity, DamageSource source) {
        if (entity.getCommandTags().contains("greywake_guest") && !state.guestDefeated) {
            state.guestDefeated = true;
            state.guestUuid = null;
            MinecraftServer server = entity.getServer();
            if (server != null) {
                state.save(server);
                for (ServerPlayerEntity player : server.getPlayerManager().getPlayerList()) {
                    player.sendMessage(Text.literal("The Wake is quiet. The scars remain."), false);
                }
            }
        }
    }

    public static boolean activateStill(ServerWorld world, BlockPos corePos, ServerPlayerEntity player, ItemStack needle) {
        if (!isValidStill(world, corePos)) {
            player.sendMessage(Text.literal("The Still is incomplete."), true);
            return false;
        }

        boolean returning = world.getRegistryKey().equals(WAKE);
        for (PendingRitual ritual : pendingRituals) {
            if (ritual.worldKey.equals(world.getRegistryKey()) && ritual.corePos.equals(corePos)) {
                player.sendMessage(Text.literal("The Still is already waking."), true);
                return false;
            }
        }
        for (ActiveRift rift : activeRifts) {
            if (rift.worldKey.equals(world.getRegistryKey()) && rift.riftPos.equals(corePos.up())) {
                player.sendMessage(Text.literal("The rift is already open."), true);
                return false;
            }
        }

        if (returning && !state.returnPoints.containsKey(player.getUuidAsString())) {
            player.sendMessage(Text.literal("The Needle cannot remember a way home."), true);
            return false;
        }

        if (!player.getAbilities().creativeMode) {
            needle.decrement(1);
        }

        pendingRituals.add(new PendingRitual(
                world.getRegistryKey(), corePos.toImmutable(), player.getUuid(), returning,
                GreywakeConfig.INSTANCE.ritualWarmupTicks
        ));

        world.playSound(null, corePos, SoundEvents.BLOCK_RESPAWN_ANCHOR_CHARGE, SoundCategory.BLOCKS, 0.7f, 0.55f);
        world.spawnParticles(ParticleTypes.ASH,
                corePos.getX() + 0.5, corePos.getY() + 1.0, corePos.getZ() + 0.5,
                18, 0.45, 0.2, 0.45, 0.01);
        player.sendMessage(Text.literal(returning ? "The Still remembers something distant." : "The Still begins to wake."), true);
        return true;
    }

    private static boolean isValidStill(ServerWorld world, BlockPos core) {
        if (!world.getBlockState(core).isOf(GreywakeContent.STILL_CORE)) return false;
        if (!world.isAir(core.up())) return false;

        BlockPos[] cardinal = {
                core.north(), core.south(), core.east(), core.west()
        };
        for (BlockPos pos : cardinal) {
            if (!world.getBlockState(pos).isOf(Blocks.SCULK)) return false;
        }

        BlockPos[] diagonals = {
                core.add(1, 0, 1), core.add(1, 0, -1),
                core.add(-1, 0, 1), core.add(-1, 0, -1)
        };
        for (BlockPos pos : diagonals) {
            if (!world.getBlockState(pos).isOf(Blocks.SOUL_SAND)) return false;
        }
        return true;
    }

    public static void tick(MinecraftServer server) {
        serverTicks++;

        tickCooldowns();
        tickRituals(server);
        tickRifts(server);
        tickWake(server);
        tickBleed(server);
        tickGuest(server);
    }

    private static void tickCooldowns() {
        Iterator<Map.Entry<UUID, Integer>> it = riftCooldown.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<UUID, Integer> entry = it.next();
            int next = entry.getValue() - 1;
            if (next <= 0) it.remove();
            else entry.setValue(next);
        }
    }

    private static void tickRituals(MinecraftServer server) {
        Iterator<PendingRitual> it = pendingRituals.iterator();
        while (it.hasNext()) {
            PendingRitual ritual = it.next();
            ServerWorld world = server.getWorld(ritual.worldKey);
            if (world == null || !isValidStill(world, ritual.corePos)) {
                it.remove();
                continue;
            }

            ritual.ticksRemaining--;
            if (ritual.ticksRemaining > 0) {
                if (ritual.ticksRemaining % 20 == 0) {
                    float pitch = 0.55f + (GreywakeConfig.INSTANCE.ritualWarmupTicks - ritual.ticksRemaining) * 0.006f;
                    world.playSound(null, ritual.corePos, SoundEvents.BLOCK_SCULK_SENSOR_CLICKING,
                            SoundCategory.BLOCKS, 0.45f, MathHelper.clamp(pitch, 0.55f, 1.25f));
                    world.spawnParticles(ParticleTypes.SOUL,
                            ritual.corePos.getX() + 0.5, ritual.corePos.getY() + 1.0, ritual.corePos.getZ() + 0.5,
                            7, 0.35, 0.35, 0.35, 0.01);
                }
                continue;
            }

            BlockPos riftPos = ritual.corePos.up();
            world.setBlockState(riftPos, GreywakeContent.RIFT.getDefaultState(), Block.NOTIFY_ALL);
            activeRifts.add(new ActiveRift(
                    ritual.worldKey, riftPos.toImmutable(), ritual.corePos.toImmutable(), ritual.returning,
                    serverTicks + GreywakeConfig.INSTANCE.riftLifetimeTicks
            ));
            world.playSound(null, riftPos, SoundEvents.BLOCK_END_PORTAL_SPAWN, SoundCategory.BLOCKS, 0.55f, 0.72f);
            world.spawnParticles(ParticleTypes.PORTAL,
                    riftPos.getX() + 0.5, riftPos.getY() + 0.5, riftPos.getZ() + 0.5,
                    48, 0.45, 0.7, 0.45, 0.03);
            it.remove();
        }
    }

    private static void tickRifts(MinecraftServer server) {
        Iterator<ActiveRift> it = activeRifts.iterator();
        while (it.hasNext()) {
            ActiveRift rift = it.next();
            ServerWorld world = server.getWorld(rift.worldKey);
            if (world == null) {
                it.remove();
                continue;
            }

            if (serverTicks >= rift.expiresAt || !world.getBlockState(rift.riftPos).isOf(GreywakeContent.RIFT)) {
                if (world.getBlockState(rift.riftPos).isOf(GreywakeContent.RIFT)) {
                    world.removeBlock(rift.riftPos, false);
                }
                it.remove();
                continue;
            }

            if (serverTicks % 8 == 0) {
                world.spawnParticles(ParticleTypes.ASH,
                        rift.riftPos.getX() + 0.5, rift.riftPos.getY() + 0.5, rift.riftPos.getZ() + 0.5,
                        3, 0.38, 0.55, 0.38, 0.003);
            }

            for (ServerPlayerEntity player : world.getPlayers()) {
                if (riftCooldown.containsKey(player.getUuid())) continue;
                double dx = player.getX() - (rift.riftPos.getX() + 0.5);
                double dy = player.getY() - rift.riftPos.getY();
                double dz = player.getZ() - (rift.riftPos.getZ() + 0.5);
                if (dx * dx + dz * dz <= 0.75 && Math.abs(dy) <= 1.6) {
                    if (rift.returning) returnFromWake(server, player);
                    else enterWake(server, player, rift.corePos);
                    riftCooldown.put(player.getUuid(), 60);
                }
            }
        }
    }

    private static void enterWake(MinecraftServer server, ServerPlayerEntity player, BlockPos stillPos) {
        ServerWorld wake = server.getWorld(WAKE);
        if (wake == null) {
            player.sendMessage(Text.literal("The Wake did not answer. Its dimension data may be missing."), false);
            Greywake.LOGGER.error("Could not enter Wake: greywake:wake world is not loaded");
            return;
        }

        state.returnPoints.put(player.getUuidAsString(), new GreywakeState.ReturnPoint(
                player.getX(), player.getY(), player.getZ(), player.getYaw(), player.getPitch()
        ));

        int exposure = state.incrementExposure(player.getUuid());
        if (exposure % Math.max(1, GreywakeConfig.INSTANCE.tripsPerBleed) == 0) {
            createOrStrengthenBleed(stillPos);
        }
        updateGuestEligibility();
        state.save(server);

        int x = MathHelper.floor(player.getX()) + GreywakeConfig.INSTANCE.wakeCoordinateOffset;
        int z = MathHelper.floor(player.getZ()) - GreywakeConfig.INSTANCE.wakeCoordinateOffset;
        int y = wake.getTopY(Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, x, z) + 1;
        y = MathHelper.clamp(y, wake.getBottomY() + 5, wake.getTopYInclusive() - 4);

        player.teleport(wake, x + 0.5, y, z + 0.5, Set.<PositionFlag>of(), player.getYaw(), player.getPitch(), true);
        player.fallDistance = 0.0f;
        player.sendMessage(Text.literal("You have entered the Wake. The way back is not free."), true);
        wake.playSound(null, BlockPos.ofFloored(x, y, z), SoundEvents.AMBIENT_CAVE, SoundCategory.AMBIENT, 0.7f, 0.55f);
    }

    private static void returnFromWake(MinecraftServer server, ServerPlayerEntity player) {
        GreywakeState.ReturnPoint point = state.returnPoints.get(player.getUuidAsString());
        ServerWorld overworld = server.getOverworld();
        if (point == null) {
            player.sendMessage(Text.literal("The way home has been forgotten."), true);
            return;
        }

        player.teleport(overworld, point.x(), point.y(), point.z(), Set.<PositionFlag>of(), point.yaw(), point.pitch(), true);
        player.fallDistance = 0.0f;
        player.sendMessage(Text.literal("You wake where you left. Something does not."), true);
        overworld.playSound(null, BlockPos.ofFloored(point.x(), point.y(), point.z()),
                SoundEvents.BLOCK_SCULK_SHRIEKER_SHRIEK, SoundCategory.AMBIENT, 0.22f, 0.7f);

        removeEchoFor(player.getUuid(), server);
        recordings.remove(player.getUuid());
    }

    private static void createOrStrengthenBleed(BlockPos origin) {
        GreywakeState.BleedPatch nearest = null;
        double nearestDistance = Double.MAX_VALUE;
        for (GreywakeState.BleedPatch patch : state.bleedPatches) {
            double d = patch.distanceSquared(origin.getX(), origin.getZ());
            if (d < nearestDistance) {
                nearestDistance = d;
                nearest = patch;
            }
        }

        if (nearest != null && nearestDistance <= 32.0 * 32.0) {
            nearest.severity++;
            nearest.radius = Math.min(32, nearest.radius + 3);
        } else {
            state.bleedPatches.add(new GreywakeState.BleedPatch(
                    origin.getX(), origin.getY(), origin.getZ(), GreywakeConfig.INSTANCE.bleedBaseRadius, 1
            ));
        }
    }

    private static void updateGuestEligibility() {
        int bleed = 0;
        for (GreywakeState.BleedPatch patch : state.bleedPatches) bleed += patch.severity;
        if (bleed >= GreywakeConfig.INSTANCE.guestBleedThreshold) state.guestEligible = true;
    }

    private static void tickWake(MinecraftServer server) {
        ServerWorld wake = server.getWorld(WAKE);
        if (wake == null) return;

        Set<UUID> currentlyInWake = new HashSet<>();
        for (ServerPlayerEntity player : wake.getPlayers()) {
            currentlyInWake.add(player.getUuid());
            ArrayDeque<MovementFrame> frames = recordings.computeIfAbsent(player.getUuid(), ignored -> new ArrayDeque<>());

            if (serverTicks % Math.max(1, GreywakeConfig.INSTANCE.echoSampleIntervalTicks) == 0) {
                frames.addLast(new MovementFrame(serverTicks, player.getX(), player.getY(), player.getZ(), player.getYaw(), player.getPitch()));
                long oldestAllowed = serverTicks - Math.max(GreywakeConfig.INSTANCE.echoDelayMaxTicks + 200, 1400);
                while (!frames.isEmpty() && frames.peekFirst().tick < oldestAllowed) frames.removeFirst();

                EchoTrack track = echoes.get(player.getUuid());
                if (track == null) {
                    int span = Math.max(0, GreywakeConfig.INSTANCE.echoDelayMaxTicks - GreywakeConfig.INSTANCE.echoDelayMinTicks);
                    int delay = GreywakeConfig.INSTANCE.echoDelayMinTicks + (span == 0 ? 0 : wake.getRandom().nextInt(span + 1));
                    MovementFrame frame = findReplayFrame(frames, serverTicks - delay);
                    if (frame != null) {
                        HuskEntity echo = spawnReplayEcho(wake, player, frame);
                        if (echo != null) {
                            echoes.put(player.getUuid(), new EchoTrack(echo.getUuid(), delay));
                        }
                    }
                } else {
                    Entity entity = wake.getEntity(track.entityUuid);
                    if (!(entity instanceof HuskEntity echo) || !echo.isAlive()) {
                        echoes.remove(player.getUuid());
                    } else {
                        MovementFrame frame = findReplayFrame(frames, serverTicks - track.delayTicks);
                        if (frame != null) {
                            echo.requestTeleport(frame.x, frame.y, frame.z);
                            echo.setYaw(frame.yaw);
                            echo.setPitch(frame.pitch);
                            echo.setHeadYaw(frame.yaw);
                        }
                    }
                }
            }

            EchoTrack track = echoes.get(player.getUuid());
            if (track != null) {
                Entity entity = wake.getEntity(track.entityUuid);
                if (entity instanceof HuskEntity echo && echo.isAlive()) {
                    tickEchoStrike(wake, player, echo, track);
                }
            }

            if (serverTicks % 3 == 0) {
                ashenWakeAround(wake, player);
            }
            if (serverTicks % 200 == 0 && wake.getRandom().nextInt(5) == 0) {
                wake.playSound(null, player.getBlockPos(), SoundEvents.AMBIENT_CAVE,
                        SoundCategory.AMBIENT, 0.35f, 0.45f + wake.getRandom().nextFloat() * 0.15f);
            }
        }

        Iterator<UUID> it = recordings.keySet().iterator();
        while (it.hasNext()) {
            UUID id = it.next();
            if (!currentlyInWake.contains(id)) it.remove();
        }
    }

    private static MovementFrame findReplayFrame(ArrayDeque<MovementFrame> frames, long targetTick) {
        MovementFrame best = null;
        for (MovementFrame frame : frames) {
            if (frame.tick <= targetTick) best = frame;
            else break;
        }
        return best;
    }

    private static HuskEntity spawnReplayEcho(ServerWorld world, ServerPlayerEntity owner, MovementFrame frame) {
        HuskEntity echo = EntityType.HUSK.create(world, SpawnReason.EVENT);
        if (echo == null) return null;
        echo.refreshPositionAndAngles(frame.x, frame.y, frame.z, frame.yaw, frame.pitch);
        echo.setCustomName(Text.literal("Echo"));
        echo.setCustomNameVisible(false);
        echo.setSilent(true);
        echo.setAiDisabled(true);
        echo.addCommandTag("greywake_echo");
        echo.addCommandTag("greywake_echo_owner_" + owner.getUuidAsString());
        EntityAttributeInstance maxHealth = echo.getAttributeInstance(EntityAttributes.MAX_HEALTH);
        if (maxHealth != null) maxHealth.setBaseValue(26.0);
        echo.setHealth(26.0f);
        world.spawnEntity(echo);
        world.spawnParticles(ParticleTypes.ASH, frame.x, frame.y + 1.0, frame.z, 24, 0.35, 0.8, 0.35, 0.02);
        return echo;
    }

    private static void tickEchoStrike(ServerWorld world, ServerPlayerEntity player, HuskEntity echo, EchoTrack track) {
        double distanceSq = echo.squaredDistanceTo(player);
        if (track.strikeTicks < 0) {
            track.strikeTicks++;
            return;
        }

        if (track.strikeTicks == 0 && distanceSq <= 2.4 * 2.4) {
            track.strikeTicks = Math.max(1, GreywakeConfig.INSTANCE.echoStrikeTelegraphTicks);
            world.playSound(null, echo.getBlockPos(), SoundEvents.BLOCK_SCULK_SENSOR_CLICKING,
                    SoundCategory.HOSTILE, 0.8f, 0.38f);
            world.spawnParticles(ParticleTypes.SOUL,
                    echo.getX(), echo.getBodyY(0.55), echo.getZ(), 16, 0.25, 0.55, 0.25, 0.01);
            player.sendMessage(Text.literal("Your Echo reaches for the place you are now."), true);
            return;
        }

        if (track.strikeTicks > 0) {
            track.strikeTicks--;
            if (track.strikeTicks == 0) {
                if (echo.isAlive() && echo.squaredDistanceTo(player) <= 2.7 * 2.7) {
                    player.damage(world, world.getDamageSources().mobAttack(echo), GreywakeConfig.INSTANCE.echoStrikeDamage);
                    world.playSound(null, player.getBlockPos(), SoundEvents.ENTITY_WARDEN_HEARTBEAT,
                            SoundCategory.HOSTILE, 0.75f, 1.15f);
                }
                track.strikeTicks = -50;
            }
        }
    }

    private static void removeEchoFor(UUID owner, MinecraftServer server) {
        EchoTrack track = echoes.remove(owner);
        if (track == null) return;
        for (ServerWorld world : server.getWorlds()) {
            Entity entity = world.getEntity(track.entityUuid);
            if (entity != null && entity.getCommandTags().contains("greywake_echo")) {
                entity.discard();
                return;
            }
        }
    }

    private static void ashenWakeAround(ServerWorld world, ServerPlayerEntity player) {
        int radius = 12;
        for (int i = 0; i < 4; i++) {
            int x = player.getBlockX() + world.getRandom().nextInt(radius * 2 + 1) - radius;
            int z = player.getBlockZ() + world.getRandom().nextInt(radius * 2 + 1) - radius;
            desaturateColumn(world, x, z, true);
        }
    }

    private static void tickBleed(MinecraftServer server) {
        if (state.bleedPatches.isEmpty()) return;
        ServerWorld overworld = server.getOverworld();

        for (ServerPlayerEntity player : overworld.getPlayers()) {
            GreywakeState.BleedPatch patch = findPatch(player.getX(), player.getZ(), 8);
            if (patch == null) continue;

            if (serverTicks % 4 == 0) {
                int x = patch.x + overworld.getRandom().nextInt(patch.radius * 2 + 1) - patch.radius;
                int z = patch.z + overworld.getRandom().nextInt(patch.radius * 2 + 1) - patch.radius;
                desaturateColumn(overworld, x, z, false);
            }

            long time = overworld.getTimeOfDay() % 24000L;
            boolean night = time >= 12500L && time <= 23500L;
            if (night && serverTicks % 300 == 0 && overworld.getRandom().nextInt(6) == 0) {
                overworld.playSound(null, player.getBlockPos(), SoundEvents.AMBIENT_CAVE,
                        SoundCategory.AMBIENT, 0.28f, 0.55f);
            }

            if (night && serverTicks % 600 == 0 && overworld.getRandom().nextInt(Math.max(5, 18 - patch.severity)) == 0) {
                spawnBleedEcho(overworld, player, patch);
            }
        }
    }

    private static GreywakeState.BleedPatch findPatch(double x, double z, int padding) {
        for (GreywakeState.BleedPatch patch : state.bleedPatches) {
            double radius = patch.radius + padding;
            if (patch.distanceSquared(x, z) <= radius * radius) return patch;
        }
        return null;
    }

    private static void desaturateColumn(ServerWorld world, int x, int z, boolean wake) {
        int y = world.getTopY(Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, x, z);
        BlockPos pos = new BlockPos(x, y, z);
        BlockState top = world.getBlockState(pos);

        Block replacement = null;
        if (top.isOf(Blocks.GRASS_BLOCK) || top.isOf(Blocks.PODZOL) || top.isOf(Blocks.MYCELIUM)) {
            replacement = wake ? Blocks.TUFF : Blocks.GRAY_TERRACOTTA;
        } else if (top.isOf(Blocks.DIRT) || top.isOf(Blocks.COARSE_DIRT) || top.isOf(Blocks.ROOTED_DIRT)) {
            replacement = Blocks.TUFF;
        } else if (top.isOf(Blocks.SAND) || top.isOf(Blocks.RED_SAND) || top.isOf(Blocks.GRAVEL)) {
            replacement = Blocks.GRAY_CONCRETE_POWDER;
        } else if (wake && (top.isOf(Blocks.STONE) || top.isOf(Blocks.ANDESITE) || top.isOf(Blocks.DIORITE) || top.isOf(Blocks.GRANITE))) {
            replacement = world.getRandom().nextBoolean() ? Blocks.TUFF : Blocks.DEEPSLATE;
        }

        if (replacement != null) {
            world.setBlockState(pos, replacement.getDefaultState(), Block.NOTIFY_LISTENERS);
            BlockPos below = pos.down();
            if (world.getBlockState(below).isOf(Blocks.DIRT)) {
                world.setBlockState(below, Blocks.TUFF.getDefaultState(), Block.NOTIFY_LISTENERS);
            }
        }
    }

    private static void spawnBleedEcho(ServerWorld world, ServerPlayerEntity player, GreywakeState.BleedPatch patch) {
        double angle = world.getRandom().nextDouble() * Math.PI * 2.0;
        int distance = 12 + world.getRandom().nextInt(10);
        int x = MathHelper.floor(player.getX() + Math.cos(angle) * distance);
        int z = MathHelper.floor(player.getZ() + Math.sin(angle) * distance);
        int y = world.getTopY(Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, x, z) + 1;

        HuskEntity echo = EntityType.HUSK.spawn(world, new BlockPos(x, y, z), SpawnReason.EVENT);
        if (echo == null) return;
        echo.setCustomName(Text.literal("Echo"));
        echo.setCustomNameVisible(false);
        echo.setSilent(true);
        echo.addCommandTag("greywake_bleed_echo");
        EntityAttributeInstance damage = echo.getAttributeInstance(EntityAttributes.ATTACK_DAMAGE);
        if (damage != null) damage.setBaseValue(4.0 + Math.min(3, patch.severity));
        world.spawnParticles(ParticleTypes.ASH, x + 0.5, y + 1.0, z + 0.5, 18, 0.3, 0.7, 0.3, 0.015);
    }

    private static void tickGuest(MinecraftServer server) {
        if (!state.guestEligible || state.guestDefeated || state.guestManifested) return;
        ServerWorld overworld = server.getOverworld();

        if (guestCountdown < 0) {
            long time = overworld.getTimeOfDay() % 24000L;
            if (time < 13000L || time > 22500L) return;

            for (ServerPlayerEntity player : overworld.getPlayers()) {
                if (findPatch(player.getX(), player.getZ(), 0) != null) {
                    guestTarget = player.getUuid();
                    guestCountdown = 160;
                    player.sendMessage(Text.literal("Something has accepted the invitation."), false);
                    overworld.playSound(null, player.getBlockPos(), SoundEvents.ENTITY_WARDEN_HEARTBEAT,
                            SoundCategory.HOSTILE, 1.1f, 0.55f);
                    break;
                }
            }
            return;
        }

        ServerPlayerEntity target = guestTarget == null ? null : server.getPlayerManager().getPlayer(guestTarget);
        if (target == null || !target.getWorld().getRegistryKey().equals(World.OVERWORLD)) {
            guestCountdown = -1;
            guestTarget = null;
            return;
        }

        guestCountdown--;
        if (guestCountdown > 0) {
            if (guestCountdown % 40 == 0) {
                overworld.playSound(null, target.getBlockPos(), SoundEvents.ENTITY_WARDEN_HEARTBEAT,
                        SoundCategory.HOSTILE, 0.9f, 0.5f + (160 - guestCountdown) * 0.002f);
                overworld.spawnParticles(ParticleTypes.ASH,
                        target.getX(), target.getY() + 1.0, target.getZ(), 12, 4.0, 1.5, 4.0, 0.01);
            }
            return;
        }

        spawnGuest(server, overworld, target);
        guestCountdown = -1;
        guestTarget = null;
    }

    private static void spawnGuest(MinecraftServer server, ServerWorld world, ServerPlayerEntity target) {
        double angle = world.getRandom().nextDouble() * Math.PI * 2.0;
        int distance = 18;
        int x = MathHelper.floor(target.getX() + Math.cos(angle) * distance);
        int z = MathHelper.floor(target.getZ() + Math.sin(angle) * distance);
        int y = world.getTopY(Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, x, z) + 1;

        WitherSkeletonEntity guest = EntityType.WITHER_SKELETON.spawn(world, new BlockPos(x, y, z), SpawnReason.EVENT);
        if (guest == null) {
            Greywake.LOGGER.warn("The Guest was eligible but could not find a valid manifestation point");
            return;
        }

        guest.setCustomName(Text.literal("The Guest"));
        guest.setCustomNameVisible(true);
        guest.setPersistent();
        guest.addCommandTag("greywake_guest");

        setBaseAttribute(guest, EntityAttributes.MAX_HEALTH, 120.0);
        setBaseAttribute(guest, EntityAttributes.ARMOR, 8.0);
        setBaseAttribute(guest, EntityAttributes.MOVEMENT_SPEED, 0.285);
        setBaseAttribute(guest, EntityAttributes.ATTACK_DAMAGE, 8.0);
        guest.setHealth(120.0f);

        state.guestManifested = true;
        state.guestUuid = guest.getUuidAsString();
        state.save(server);

        world.playSound(null, guest.getBlockPos(), SoundEvents.ENTITY_WITHER_SPAWN, SoundCategory.HOSTILE, 0.55f, 0.65f);
        world.spawnParticles(ParticleTypes.SOUL, guest.getX(), guest.getY() + 1.0, guest.getZ(), 64, 1.4, 1.6, 1.4, 0.025);
        target.sendMessage(Text.literal("The Guest has arrived."), false);
    }

    private static void setBaseAttribute(LivingEntity entity, net.minecraft.registry.entry.RegistryEntry<net.minecraft.entity.attribute.EntityAttribute> attribute, double value) {
        EntityAttributeInstance instance = entity.getAttributeInstance(attribute);
        if (instance != null) instance.setBaseValue(value);
    }

    private record MovementFrame(long tick, double x, double y, double z, float yaw, float pitch) {}

    private static final class EchoTrack {
        private final UUID entityUuid;
        private final int delayTicks;
        private int strikeTicks;

        private EchoTrack(UUID entityUuid, int delayTicks) {
            this.entityUuid = entityUuid;
            this.delayTicks = delayTicks;
        }
    }

    private static final class PendingRitual {
        private final RegistryKey<World> worldKey;
        private final BlockPos corePos;
        @SuppressWarnings("unused")
        private final UUID activator;
        private final boolean returning;
        private int ticksRemaining;

        private PendingRitual(RegistryKey<World> worldKey, BlockPos corePos, UUID activator, boolean returning, int ticksRemaining) {
            this.worldKey = worldKey;
            this.corePos = corePos;
            this.activator = activator;
            this.returning = returning;
            this.ticksRemaining = ticksRemaining;
        }
    }

    private record ActiveRift(RegistryKey<World> worldKey, BlockPos riftPos, BlockPos corePos,
                              boolean returning, long expiresAt) {}
}

package dev.plodroid.greywake;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.WorldSavePath;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public final class GreywakeState {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    public Map<String, Integer> exposure = new HashMap<>();
    public Map<String, ReturnPoint> returnPoints = new HashMap<>();
    public List<BleedPatch> bleedPatches = new ArrayList<>();

    public boolean guestEligible;
    public boolean guestManifested;
    public boolean guestDefeated;
    public String guestUuid;

    public static GreywakeState load(MinecraftServer server) {
        Path path = path(server);
        if (!Files.exists(path)) return new GreywakeState();
        try {
            GreywakeState state = GSON.fromJson(Files.readString(path, StandardCharsets.UTF_8), GreywakeState.class);
            return state == null ? new GreywakeState() : state;
        } catch (Exception e) {
            Greywake.LOGGER.error("Could not load Greywake world state; starting with a clean state", e);
            return new GreywakeState();
        }
    }

    public void save(MinecraftServer server) {
        Path path = path(server);
        try {
            Files.createDirectories(path.getParent());
            Files.writeString(path, GSON.toJson(this), StandardCharsets.UTF_8);
        } catch (IOException e) {
            Greywake.LOGGER.error("Could not save Greywake world state", e);
        }
    }

    private static Path path(MinecraftServer server) {
        return server.getSavePath(WorldSavePath.ROOT).resolve("greywake-state.json");
    }

    public int incrementExposure(UUID player) {
        String key = player.toString();
        int value = exposure.getOrDefault(key, 0) + 1;
        exposure.put(key, value);
        return value;
    }

    public record ReturnPoint(double x, double y, double z, float yaw, float pitch) {}

    public static final class BleedPatch {
        public int x;
        public int y;
        public int z;
        public int radius;
        public int severity;

        public BleedPatch() {}

        public BleedPatch(int x, int y, int z, int radius, int severity) {
            this.x = x;
            this.y = y;
            this.z = z;
            this.radius = radius;
            this.severity = severity;
        }

        public double distanceSquared(double px, double pz) {
            double dx = px - x;
            double dz = pz - z;
            return dx * dx + dz * dz;
        }
    }
}

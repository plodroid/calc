package dev.plodroid.greywake;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.util.Identifier;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public final class Greywake implements ModInitializer {
    public static final String MOD_ID = "greywake";
    public static final Logger LOGGER = LoggerFactory.getLogger("Greywake");

    public static Identifier id(String path) {
        return Identifier.of(MOD_ID, path);
    }

    @Override
    public void onInitialize() {
        GreywakeContent.initialize();
        GreywakeConfig.load();

        ServerLifecycleEvents.SERVER_STARTED.register(GreywakeServer::onServerStarted);
        ServerLifecycleEvents.SERVER_STOPPING.register(GreywakeServer::onServerStopping);
        ServerTickEvents.END_SERVER_TICK.register(GreywakeServer::tick);
        ServerLivingEntityEvents.AFTER_DEATH.register(GreywakeServer::onLivingDeath);

        LOGGER.info("Greywake 1.0.0 initialized for Minecraft 1.21.11.");
    }
}

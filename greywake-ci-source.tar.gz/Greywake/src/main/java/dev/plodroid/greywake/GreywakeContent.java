package dev.plodroid.greywake;

import net.minecraft.block.AbstractBlock;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.block.MapColor;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.item.Rarity;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;

public final class GreywakeContent {
    private GreywakeContent() {}

    public static final Block STILL_CORE = registerBlock(
            "still_core",
            AbstractBlock.Settings.create()
                    .mapColor(MapColor.DEEPSLATE_GRAY)
                    .strength(4.5f, 8.0f)
                    .sounds(Blocks.DEEPSLATE_TILES.getDefaultState().getSoundGroup())
    );

    public static final Block RIFT = registerBlockOnly(
            "rift",
            AbstractBlock.Settings.create()
                    .mapColor(MapColor.BLACK)
                    .strength(-1.0f, 3_600_000.0f)
                    .noCollision()
                    .nonOpaque()
                    .luminance(state -> 3)
    );

    public static final Item WAKE_NEEDLE = registerItem(
            "wake_needle",
            settings -> new WakeNeedleItem(settings.maxCount(1).rarity(Rarity.UNCOMMON))
    );

    private static Block registerBlock(String path, AbstractBlock.Settings settings) {
        RegistryKey<Block> blockKey = RegistryKey.of(RegistryKeys.BLOCK, Greywake.id(path));
        Block block = Registry.register(Registries.BLOCK, blockKey, new Block(settings.registryKey(blockKey)));

        RegistryKey<Item> itemKey = RegistryKey.of(RegistryKeys.ITEM, Greywake.id(path));
        Registry.register(Registries.ITEM, itemKey,
                new BlockItem(block, new Item.Settings().registryKey(itemKey).useBlockPrefixedTranslationKey()));
        return block;
    }

    private static Block registerBlockOnly(String path, AbstractBlock.Settings settings) {
        RegistryKey<Block> key = RegistryKey.of(RegistryKeys.BLOCK, Greywake.id(path));
        return Registry.register(Registries.BLOCK, key, new Block(settings.registryKey(key)));
    }

    private static Item registerItem(String path, ItemFactory factory) {
        RegistryKey<Item> key = RegistryKey.of(RegistryKeys.ITEM, Greywake.id(path));
        return Registry.register(Registries.ITEM, key, factory.create(new Item.Settings().registryKey(key)));
    }

    public static void initialize() {
        // Class loading performs registration.
    }

    @FunctionalInterface
    private interface ItemFactory {
        Item create(Item.Settings settings);
    }
}
